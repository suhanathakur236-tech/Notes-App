import { useState, useEffect } from "react";
import "./App.css";

function App() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  // FIX 1: Index ki jagah Unique ID track karenge taaki sorting/search se koi farq na pade
  const [editId, setEditId] = useState(null);
  const [search, setSearch] = useState("");
  const [darkMode, setDarkMode] = useState(false);
  
  const [notes, setNotes] = useState(() => {
    const savedNotes = localStorage.getItem("notes");
    return savedNotes ? JSON.parse(savedNotes) : [];
  });

  useEffect(() => {
    localStorage.setItem("notes", JSON.stringify(notes));
  }, [notes]);

  const addNote = () => {
    // .trim() use karne se agar koi sirf space bar dabayega toh bhi empty submit nahi hoga
    if (!title.trim() || !description.trim()) {
      alert("Please fill all fields");
      return;
    }

    if (editId !== null) {
      // FIX 2: ID ke basis par note ko update kiya
      const updatedNotes = notes.map((note) =>
        note.id === editId ? { ...note, title, description } : note
      );
      setNotes(updatedNotes);
    } else {
      const newNote = {
        id: Date.now(), 
        title, 
        description, 
        date: new Date().toLocaleString(),
        pinned: false
      };
      
      // Naya note hamesha unpinned list mein sabse upar dikhane ke liye
      const updatedNotes = [...notes, newNote];
      updatedNotes.sort((a, b) => b.pinned - a.pinned);
      setNotes(updatedNotes);
    }

    setTitle("");
    setDescription("");
    setEditId(null);
  };
    
  const deleteNote = (id) => {
    // FIX 3: ID ke basis par delete kiya
    setNotes(notes.filter((note) => note.id !== id));
    if (editId === id) {
      setEditId(null);
      setTitle("");
      setDescription("");
    }
  };

  const startEdit = (note) => {
    // FIX 4: Pure note object ko le kar uski ID ko edit state mein daal diya
    setTitle(note.title); 
    setDescription(note.description); 
    setEditId(note.id); 
  };

  const pinNote = (id) => {
    const updatedNotes = notes.map((note) => {
      if (note.id === id) {
        return { ...note, pinned: !note.pinned };
      }
      return note;
    });

    // Pinned notes upar rahenge, aur baki notes apni purani jagah hi rahenge
    updatedNotes.sort((a, b) => b.pinned - a.pinned);
    setNotes(updatedNotes);

    // Pin badalne par index badalta hai, isliye chalte hue edit ko reset karna safe hai
    if (editId === id) {
      setEditId(null);
      setTitle("");
      setDescription("");
    }
  };

  return (
    <div className={darkMode ? "dark" : "light"}>
      <div className="container">
        <h1>Notes App</h1>
        
        <input type="text" onChange={(e) => setTitle(e.target.value)} placeholder="Enter title" value={title}/>
        <textarea onChange={(e) => setDescription(e.target.value)} placeholder="Enter description" value={description}></textarea>
        <button className="add-btn" onClick={addNote}>
          {editId !== null ? "Update Note" : "Add Notes"}
        </button>

        <hr />

        <h3>Search Notes</h3>
        <input className="search-input"
          type="text" 
          placeholder="Type to search..." 
          value={search} 
          onChange={(e) => setSearch(e.target.value)}
        />

        <section>
          {notes
            .filter((note) => 
              note.title.toLowerCase().includes(search.toLowerCase()) ||
              note.description.toLowerCase().includes(search.toLowerCase())
            )
            .map((note) => {
              return (
                <div key={note.id} style={{ border: "1px solid #ccc", padding: "10px", margin: "10px 0", backgroundColor: note.pinned ? "#fffde7" : "transparent" }}>
                  <h3>{note.title} {note.pinned ? "📌" : ""}</h3>
                  <p>{note.description}</p>
                  <p className="date">{note.date}</p>
                  <br />
                  {/* Ab hum functions mein seedhe note.id bhej rahe hain, jo 100% accurate hai */}
                  <button className="delete-btn" onClick={() => deleteNote(note.id)}>Delete</button>
                  <button className="edit-btn" onClick={() => startEdit(note)}>Edit</button>
                  <button onClick={() => pinNote(note.id)}>
                    {note.pinned ? "Unpin" : "Pin"}
                  </button>
                </div>
              );
            })}
        </section>
        
        <button onClick={() => setDarkMode(!darkMode)}>
          {darkMode ? "Light Mode" : "Dark Mode"}
        </button>
      </div>
    </div>
  );
}

export default App;
